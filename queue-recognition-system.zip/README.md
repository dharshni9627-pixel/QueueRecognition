# Queue Recognition System

A focused 35% MVP prototype for analyzing queue images. Upload a JPG, JPEG, or PNG, detect people through a Python/YOLO API, count them, and classify the queue size.

## Run locally

```sh
bun install
bun run dev
```

The frontend is available at the local URL shown by Vite.

## Configure the detection API

Copy the example environment file and add your backend URL:

```sh
cp .env.example .env
```

```env
VITE_API_URL=https://your-detection-api.example.com
```

The app sends the uploaded image as `multipart/form-data` in a field called `image` to `POST ${VITE_API_URL}/analyze`. The backend should return:

```json
{
  "person_count": 8,
  "queue_detected": true,
  "queue_status": "Moderate",
  "confidence": 0.91,
  "detected_image": "image URL or base64 image"
}
```

`detected_image` is optional. When it is missing, the frontend displays the original uploaded image. The frontend applies the queue status rules from the returned person count so the classification remains consistent.

## Demo Mode

Demo Mode is enabled by default so the complete workflow can be demonstrated without a backend. It waits briefly and returns a clearly labelled sample result of 8 people with 91% confidence. Turn Demo Mode off to send the image to `VITE_API_URL`; the app never invents an API result when API mode is selected.

## Validation and errors

- Supported files: JPG, JPEG, and PNG
- Maximum file size: 10 MB
- Clear messages for missing images, unsupported files, oversized files, unavailable APIs, and invalid API responses
- Camera and webcam access are not used

## Queue status rules

| People detected | Status |
| --- | --- |
| 0–2 | No Queue |
| 3–5 | Small Queue |
| 6–10 | Moderate Queue |
| More than 10 | Large Queue |

## Export or deploy

The project is a standard React + TypeScript + Tailwind CSS app. To export it, download the project files from your workspace or connect the repository to GitHub. For a production build, run:

```sh
bun run build
```

Deploy the generated app using your preferred static hosting platform and set `VITE_API_URL` in that platform's environment settings.
