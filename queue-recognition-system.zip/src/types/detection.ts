export const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/png"] as const;
export const MAX_IMAGE_SIZE_BYTES = 10 * 1024 * 1024;

export type QueueStatus = "No Queue" | "Small Queue" | "Moderate Queue" | "Large Queue";

export type DetectionResult = {
  person_count: number;
  queue_detected: boolean;
  queue_status: QueueStatus;
  confidence: number;
  detected_image?: string;
};

export function getQueueStatus(personCount: number): QueueStatus {
  if (personCount <= 2) return "No Queue";
  if (personCount <= 5) return "Small Queue";
  if (personCount <= 10) return "Moderate Queue";
  return "Large Queue";
}

export function isSupportedImage(file: File) {
  return ACCEPTED_IMAGE_TYPES.includes(file.type as (typeof ACCEPTED_IMAGE_TYPES)[number]);
}

export function isDetectionResult(value: unknown): value is DetectionResult {
  if (!value || typeof value !== "object") return false;
  const result = value as Record<string, unknown>;
  return (
    typeof result["person_count"] === "number" &&
    Number.isInteger(result["person_count"]) &&
    result["person_count"] >= 0 &&
    typeof result["queue_detected"] === "boolean" &&
    typeof result["queue_status"] === "string" &&
    typeof result["confidence"] === "number" &&
    result["confidence"] >= 0 &&
    result["confidence"] <= 1 &&
    (result["detected_image"] === undefined || typeof result["detected_image"] === "string")
  );
}
