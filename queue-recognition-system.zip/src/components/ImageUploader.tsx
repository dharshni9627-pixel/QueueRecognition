import { FileImage, ImagePlus, Upload, X } from "lucide-react";
import { useRef, useState, type DragEvent, type ChangeEvent } from "react";
import { Button } from "@/components/ui/button";
import {
  ACCEPTED_IMAGE_TYPES,
  MAX_IMAGE_SIZE_BYTES,
  isSupportedImage,
} from "@/types/detection";

type ImageUploaderProps = {
  file: File | null;
  previewUrl: string | null;
  error: string | null;
  onFileSelected: (file: File) => void;
  onRemove: () => void;
};

const maxSizeLabel = "10 MB";

export function ImageUploader({
  file,
  previewUrl,
  error,
  onFileSelected,
  onRemove,
}: ImageUploaderProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  function handleFile(candidate: File | undefined) {
    if (!candidate) return;
    if (!isSupportedImage(candidate)) {
      onFileSelected(Object.assign(new File([], candidate.name), { __uploadError: "Unsupported file type. Choose a JPG, JPEG, or PNG image." }));
      return;
    }
    if (candidate.size > MAX_IMAGE_SIZE_BYTES) {
      onFileSelected(Object.assign(new File([], candidate.name), { __uploadError: `Image is too large. Please choose an image under ${maxSizeLabel}.` }));
      return;
    }
    onFileSelected(candidate);
  }

  function onInputChange(event: ChangeEvent<HTMLInputElement>) {
    handleFile(event.target.files?.[0]);
    event.target.value = "";
  }

  function onDrop(event: DragEvent<HTMLDivElement>) {
    event.preventDefault();
    setIsDragging(false);
    handleFile(event.dataTransfer.files[0]);
  }

  return (
    <div className="space-y-4">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="mb-2 flex items-center gap-2 text-sm font-semibold text-primary">
            <span className="flex size-6 items-center justify-center rounded-full bg-primary/10 text-xs">01</span>
            Input image
          </div>
          <h2 className="font-display text-xl font-bold tracking-tight text-foreground">Upload Queue Image</h2>
          <p className="mt-1 max-w-xl text-sm leading-6 text-muted-foreground">
            Upload an image containing people standing in a queue. Camera access is not required.
          </p>
        </div>
        {file && (
          <Button type="button" variant="ghost" size="icon" onClick={onRemove} aria-label="Remove uploaded image">
            <X className="size-4" />
          </Button>
        )}
      </div>

      {!previewUrl ? (
        <div
          onDragOver={(event) => {
            event.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={onDrop}
          className={`flex min-h-56 flex-col items-center justify-center rounded-2xl border border-dashed px-6 py-10 text-center transition-colors ${
            isDragging ? "border-primary bg-primary/5" : "border-border bg-muted/30"
          }`}
        >
          <div className="mb-4 flex size-14 items-center justify-center rounded-2xl bg-background text-primary shadow-sm ring-1 ring-border">
            <ImagePlus className="size-6" aria-hidden="true" />
          </div>
          <p className="text-sm font-semibold text-foreground">Drop a queue image here</p>
          <p className="mt-1 text-xs text-muted-foreground">JPG, JPEG, or PNG · max {maxSizeLabel}</p>
          <input
            ref={inputRef}
            type="file"
            accept={ACCEPTED_IMAGE_TYPES.join(",")}
            onChange={onInputChange}
            className="sr-only"
          />
          <Button type="button" variant="outline" className="mt-5" onClick={() => inputRef.current?.click()}>
            <Upload className="size-4" />
            Choose image
          </Button>
        </div>
      ) : (
        <div className="overflow-hidden rounded-2xl border border-border bg-muted/20">
          <div className="relative aspect-[16/8] min-h-52 w-full bg-muted">
            <img src={previewUrl} alt={`Preview of ${file?.name ?? "uploaded queue image"}`} className="size-full object-cover" />
            <div className="absolute inset-x-0 bottom-0 flex items-center gap-2 bg-foreground/75 px-4 py-3 text-primary-foreground backdrop-blur-sm">
              <FileImage className="size-4 shrink-0" aria-hidden="true" />
              <span className="truncate text-sm font-medium">{file?.name}</span>
              <span className="ml-auto shrink-0 text-xs opacity-75">Ready to analyze</span>
            </div>
          </div>
        </div>
      )}

      {error && <p className="text-sm font-medium text-destructive" role="alert">{error}</p>}
    </div>
  );
}
