import { Loader2, ScanSearch } from "lucide-react";
import { Button } from "@/components/ui/button";

type AnalysisButtonProps = {
  disabled: boolean;
  isAnalyzing: boolean;
  onClick: () => void;
};

export function AnalysisButton({ disabled, isAnalyzing, onClick }: AnalysisButtonProps) {
  return (
    <Button type="button" size="lg" className="w-full sm:w-auto" disabled={disabled || isAnalyzing} onClick={onClick}>
      {isAnalyzing ? <Loader2 className="size-4 animate-spin" /> : <ScanSearch className="size-4" />}
      {isAnalyzing ? "Analyzing image..." : "Analyze Queue"}
    </Button>
  );
}
