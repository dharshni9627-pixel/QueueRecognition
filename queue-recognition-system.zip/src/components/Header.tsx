import { Activity, ShieldCheck } from "lucide-react";

export function Header() {
  return (
    <header className="border-b border-border/80 bg-background/95">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-5 sm:px-8">
        <div className="flex items-center gap-3">
          <div className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm">
            <Activity className="size-5" aria-hidden="true" />
          </div>
          <div>
            <p className="font-display text-base font-bold tracking-tight text-foreground">Queue Recognition</p>
            <p className="text-xs text-muted-foreground">Vision analysis workspace</p>
          </div>
        </div>
        <div className="hidden items-center gap-2 text-xs font-medium text-muted-foreground sm:flex">
          <ShieldCheck className="size-4 text-success" aria-hidden="true" />
          <span>Upload-only analysis</span>
        </div>
      </div>
    </header>
  );
}
