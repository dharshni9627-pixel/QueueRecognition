import { ScanLine } from "lucide-react";

type DetectedImageProps = {
  imageUrl: string | null;
  originalImageUrl: string;
  isDemoMode: boolean;
};

export function DetectedImage({ imageUrl, originalImageUrl, isDemoMode }: DetectedImageProps) {
  return (
    <section aria-labelledby="detected-image-heading" className="rounded-2xl border border-border bg-background p-5 shadow-card sm:p-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="mb-2 flex items-center gap-2 text-sm font-semibold text-primary">
            <span className="flex size-6 items-center justify-center rounded-full bg-primary/10 text-xs">03</span>
            Visual verification
          </div>
          <h2 id="detected-image-heading" className="font-display text-xl font-bold tracking-tight text-foreground">Detected People</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {imageUrl ? "Processed image returned by the detection service." : "Original upload shown because no processed image was returned."}
          </p>
        </div>
        <span className="flex items-center gap-2 rounded-full bg-muted px-3 py-1.5 text-xs font-semibold text-muted-foreground">
          <ScanLine className="size-3.5" aria-hidden="true" />
          {isDemoMode ? "Sample analysis" : "Image result"}
        </span>
      </div>
      <div className="mt-5 overflow-hidden rounded-xl border border-border bg-muted/30">
        <img src={imageUrl ?? originalImageUrl} alt="Queue image with detected people" className="max-h-[520px] w-full object-contain" />
      </div>
    </section>
  );
}
