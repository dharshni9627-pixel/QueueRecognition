import { CheckCircle2, Gauge, Layers3, UsersRound } from "lucide-react";
import type { DetectionResult } from "@/types/detection";
import { ResultCard } from "@/components/ResultCard";

type ResultsDashboardProps = {
  result: DetectionResult;
  isDemoMode: boolean;
};

export function ResultsDashboard({ result, isDemoMode }: ResultsDashboardProps) {
  return (
    <section aria-labelledby="results-heading" className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <div className="mb-2 flex items-center gap-2 text-sm font-semibold text-primary">
            <span className="flex size-6 items-center justify-center rounded-full bg-primary/10 text-xs">02</span>
            Analysis output
          </div>
          <h2 id="results-heading" className="font-display text-xl font-bold tracking-tight text-foreground">Results Dashboard</h2>
        </div>
        {isDemoMode && <span className="rounded-full bg-warning/15 px-3 py-1.5 text-xs font-bold text-warning-foreground">DEMO MODE</span>}
      </div>
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <ResultCard label="People detected" value={`${result.person_count}`} detail="People found in the image" icon={UsersRound} tone="blue" />
        <ResultCard label="Queue detected" value={result.queue_detected ? "YES" : "NO"} detail={result.queue_detected ? "A queue pattern was found" : "No queue pattern found"} icon={CheckCircle2} tone={result.queue_detected ? "green" : "navy"} />
        <ResultCard label="Queue status" value={result.queue_status.replace(" Queue", "")} detail="Based on the people count" icon={Layers3} tone="amber" />
        <ResultCard label="Confidence" value={`${Math.round(result.confidence * 100)}%`} detail="Model detection confidence" icon={Gauge} tone="navy" />
      </div>
    </section>
  );
}
