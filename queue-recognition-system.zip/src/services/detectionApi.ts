import {
  getQueueStatus,
  isDetectionResult,
  type DetectionResult,
} from "@/types/detection";

export class DetectionApiError extends Error {
  constructor(
    message: string,
    public readonly kind: "unavailable" | "invalid" | "request",
  ) {
    super(message);
    this.name = "DetectionApiError";
  }
}

const demoResult: DetectionResult = {
  person_count: 8,
  queue_detected: true,
  queue_status: "Moderate Queue",
  confidence: 0.91,
};

function getApiUrl() {
  return import.meta.env["VITE_API_URL"]?.trim().replace(/\/$/, "");
}

export async function analyzeQueue(image: File, demoMode: boolean): Promise<DetectionResult> {
  if (demoMode) {
    await new Promise((resolve) => window.setTimeout(resolve, 850));
    return demoResult;
  }

  const apiUrl = getApiUrl();
  if (!apiUrl) {
    throw new DetectionApiError(
      "Detection API is unavailable. Configure VITE_API_URL or enable Demo Mode.",
      "unavailable",
    );
  }

  const formData = new FormData();
  formData.append("image", image);

  let response: Response;
  try {
    response = await fetch(`${apiUrl}/analyze`, {
      method: "POST",
      body: formData,
    });
  } catch {
    throw new DetectionApiError(
      "Could not reach the detection API. Check that the backend is running and try again.",
      "unavailable",
    );
  }

  if (!response.ok) {
    throw new DetectionApiError(
      `The detection API returned an error (${response.status}). Please try again.`,
      response.status >= 500 ? "unavailable" : "request",
    );
  }

  let data: unknown;
  try {
    data = await response.json();
  } catch {
    throw new DetectionApiError("The detection API returned an unreadable response.", "invalid");
  }

  if (!isDetectionResult(data)) {
    throw new DetectionApiError(
      "The detection API response is invalid. Check it matches the documented format.",
      "invalid",
    );
  }

  return {
    ...data,
    queue_status: getQueueStatus(data.person_count),
  };
}
