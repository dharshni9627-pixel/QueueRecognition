import { useEffect, useMemo, useState } from "react";
import { AlertCircle, ArrowRight, Check, Info, Sparkles } from "lucide-react";
import { createFileRoute } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/Header";
import { ImageUploader } from "@/components/ImageUploader";
import { AnalysisButton } from "@/components/AnalysisButton";
import { ResultsDashboard } from "@/components/ResultsDashboard";
import { DetectedImage } from "@/components/DetectedImage";
import { analyzeQueue, DetectionApiError } from "@/services/detectionApi";
import { getQueueStatus, type DetectionResult } from "@/types/detection";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Queue Recognition — AI Queue Analysis" },
      { name: "description", content: "Analyze uploaded queue images, count detected people, and classify queue status." },
      { property: "og:title", content: "Queue Recognition — AI Queue Analysis" },
      { property: "og:description", content: "Upload an image to detect people and understand queue size in seconds." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

type UploadFile = File & { __uploadError?: string };

function Index() {
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [result, setResult] = useState<DetectionResult | null>(null);
  const [isDemoMode, setIsDemoMode] = useState(true);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!file || (file as UploadFile).__uploadError) {
      setPreviewUrl(null);
      return;
    }
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  const hasApi = Boolean(import.meta.env["VITE_API_URL"]?.trim());
  const detectedImageUrl = useMemo(() => result?.detected_image ?? null, [result]);

  function handleFileSelected(selectedFile: File) {
    const uploadFile = selectedFile as UploadFile;
    setFile(selectedFile);
    setResult(null);
    setError(uploadFile.__uploadError ?? null);
  }

  function handleRemove() {
    setFile(null);
    setPreviewUrl(null);
    setResult(null);
    setError(null);
  }

  async function handleAnalyze() {
    if (!file) {
      setError("Please select an image before analyzing.");
      return;
    }
    if ((file as UploadFile).__uploadError) return;
    setError(null);
    setResult(null);
    setIsAnalyzing(true);
    try {
      const detection = await analyzeQueue(file, isDemoMode);
      setResult({ ...detection, queue_status: getQueueStatus(detection.person_count) });
    } catch (analysisError) {
      if (analysisError instanceof DetectionApiError) {
        setError(analysisError.message);
      } else {
        setError("The image could not be analyzed. Please try again.");
      }
    } finally {
      setIsAnalyzing(false);
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="mx-auto max-w-6xl px-5 pb-16 pt-10 sm:px-8 sm:pt-14">
        <section className="mb-10 flex flex-col justify-between gap-8 lg:flex-row lg:items-end">
          <div className="max-w-2xl">
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-3 py-1.5 text-xs font-bold text-primary">
              <Sparkles className="size-3.5" aria-hidden="true" />
              Queue intelligence · MVP prototype
            </div>
            <h1 className="font-display text-4xl font-bold tracking-tight text-foreground sm:text-5xl">See the queue at a glance.</h1>
            <p className="mt-4 max-w-xl text-base leading-7 text-muted-foreground sm:text-lg">
              AI-powered queue analysis from uploaded images. Detect people, understand queue size, and validate the result visually.
            </p>
          </div>
          <div className="grid w-full max-w-sm grid-cols-3 gap-2 rounded-2xl border border-border bg-muted/35 p-2 text-center lg:w-[330px]">
            <div className="rounded-xl bg-background px-3 py-3 shadow-sm"><p className="font-display text-lg font-bold text-foreground">01</p><p className="mt-1 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Upload</p></div>
            <div className="flex items-center justify-center text-border"><ArrowRight className="size-4" aria-hidden="true" /></div>
            <div className="rounded-xl bg-background px-3 py-3 shadow-sm"><p className="font-display text-lg font-bold text-foreground">02</p><p className="mt-1 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Analyze</p></div>
          </div>
        </section>

        <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_300px]">
          <section className="rounded-2xl border border-border bg-background p-5 shadow-card sm:p-7">
            <ImageUploader file={file} previewUrl={previewUrl} error={error} onFileSelected={handleFileSelected} onRemove={handleRemove} />
            <div className="mt-6 flex flex-col gap-4 border-t border-border pt-5 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  role="switch"
                  aria-checked={isDemoMode}
                  onClick={() => {
                    setIsDemoMode((enabled) => !enabled);
                    setResult(null);
                    setError(null);
                  }}
                  className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 ${isDemoMode ? "bg-primary" : "bg-border"}`}
                >
                  <span className={`pointer-events-none mt-0.5 size-5 rounded-full bg-background shadow-sm transition-transform ${isDemoMode ? "translate-x-5" : "translate-x-0.5"}`} />
                </button>
                <div>
                  <p className="text-sm font-semibold text-foreground">Demo Mode</p>
                  <p className="text-xs text-muted-foreground">{isDemoMode ? "Uses a sample detection result" : hasApi ? "Sends image to your API" : "Needs VITE_API_URL to run"}</p>
                </div>
              </div>
              <AnalysisButton disabled={!file || Boolean((file as UploadFile).__uploadError)} isAnalyzing={isAnalyzing} onClick={handleAnalyze} />
            </div>
            <div className="mt-4 flex items-start gap-2 text-xs leading-5 text-muted-foreground">
              <Info className="mt-0.5 size-3.5 shrink-0 text-primary" aria-hidden="true" />
              <p>{isDemoMode ? "Demo results are clearly labelled and are not real AI detections." : "Your uploaded image will be sent to the configured person-detection API."}</p>
            </div>
          </section>

          <aside className="rounded-2xl border border-border bg-navy-surface p-6 text-primary-foreground shadow-card">
            <p className="text-xs font-bold uppercase tracking-[0.14em] text-primary-foreground/65">Queue rule set</p>
            <h2 className="mt-3 font-display text-xl font-bold tracking-tight">Simple, explainable status</h2>
            <div className="mt-6 space-y-3 text-sm">
              {["0–2 people · No Queue", "3–5 people · Small Queue", "6–10 people · Moderate Queue", ">10 people · Large Queue"].map((rule) => (
                <div key={rule} className="flex items-center gap-2 border-b border-primary-foreground/10 pb-3 last:border-0 last:pb-0">
                  <Check className="size-4 shrink-0 text-primary" aria-hidden="true" />
                  <span className="text-primary-foreground/80">{rule}</span>
                </div>
              ))}
            </div>
          </aside>
        </div>

        {isAnalyzing && (
          <div className="mt-8 flex items-center gap-3 rounded-2xl border border-primary/20 bg-primary/5 px-5 py-4 text-sm text-primary" role="status">
            <span className="size-2 animate-pulse rounded-full bg-primary" />
            <span className="font-medium">Scanning the uploaded image for people...</span>
          </div>
        )}

        {error && !isAnalyzing && (
          <div className="mt-8 flex items-start gap-3 rounded-2xl border border-destructive/20 bg-destructive/5 px-5 py-4 text-sm text-destructive" role="alert">
            <AlertCircle className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
            <div><p className="font-semibold">Analysis could not be completed</p><p className="mt-1 opacity-85">{error}</p></div>
          </div>
        )}

        {result && previewUrl && (
          <div className="mt-10 space-y-8">
            <ResultsDashboard result={result} isDemoMode={isDemoMode} />
            <DetectedImage imageUrl={detectedImageUrl} originalImageUrl={previewUrl} isDemoMode={isDemoMode} />
          </div>
        )}

        <section className="mt-12 border-t border-border pt-8" aria-labelledby="how-it-works-heading">
          <div className="mb-5 flex items-center gap-3">
            <div className="flex size-9 items-center justify-center rounded-xl bg-secondary text-primary"><Info className="size-4" aria-hidden="true" /></div>
            <h2 id="how-it-works-heading" className="font-display text-xl font-bold tracking-tight text-foreground">How it works</h2>
          </div>
          <div className="grid gap-3 text-sm text-muted-foreground sm:grid-cols-4">
            {["Upload a queue image.", "AI detects people in the image.", "The system counts detected people.", "The system displays the queue status."].map((step, index) => (
              <div key={step} className="flex gap-3 rounded-xl border border-border bg-muted/25 p-4 leading-5">
                <span className="font-display font-bold text-primary">0{index + 1}</span><span>{step}</span>
              </div>
            ))}
          </div>
          <p className="mt-5 text-xs text-muted-foreground">Camera access is not required. The system analyzes uploaded images.</p>
        </section>
      </main>
    </div>
  );
}
